# Plugins — Index

Every folder in `/plugins/<name>/` is a self-contained unit (manifest + `index.js`). This is the
fast lookup: **which plugin owns a given verb or mechanic, and how it hooks into the engine.** For the
manifest schema and README convention, see [plugin-standard.md](plugin-standard.md). For the load
mechanism, see `server/engine/plugins.js`.

## ⚠️ Command precedence — plugins win over engine builtins

This is the single most important thing to know before editing any player command. The dispatch order
in `server/engine/commands/index.js` (`handleCommand`) is:

1. SIFT selection-state intercept
2. `fireInputMatchers(…)` — raw-input regex matchers for multi-word verbs (`registerInputMatcher`;
   the MIS plugin registers "jerk off on" / "eat out" through this)
3. **`fireCommand(cmd, …)` — plugin-registered commands** ← runs first
4. `fireSpecializedAction(cmd, …)` — tag-gated specialized actions (also plugins)
5. **`builtins.get(cmd)` — engine handlers** in `server/engine/commands/*.js` ← runs last

(The old `use` cosmetic-machine pre-intercept is gone — the cosmetic-machine plugin self-gates a
`use` specialized action instead.)

So if a plugin registers a verb (e.g. `sit`), the matching handler in `server/engine/commands/*.js`
is **dead code** — it never executes. A verb can have an engine handler *and* a plugin handler; the
plugin always wins. When a command "doesn't behave like the engine code says," check the plugin
registry **first**. (This exact trap caused the posture/HP-regen bug — see
[systems-posture.md](systems-posture.md).)

The loader now makes collisions visible at boot: it **warns** when a plugin verb overrides another
plugin's, and prints an ℹ line listing every plugin verb that shadows an engine builtin. Load order
is filesystem-alphabetical unless a manifest declares `"after": ["otherPlugin", …]` — use it whenever
a verb override is intentional (gametable does this to win `watch` from broadcast + interactions).
A manifest may also declare `"critical": true`: that plugin failing to load aborts boot instead of
logging and limping on (the weapon plugin is critical — without it nobody can fight).

To list what's actually registered at runtime: `getRegisteredCommands()` in `plugins.js`.

**Before deploying any change to verbs, seams, or plugins, run `npm run test:regress`** — it sweeps
every manifest against the live registries and runs each plugin's `regress.js` suite (see
[plugin-standard.md](plugin-standard.md) and CLAUDE.md "Regression testing").

## Plugin catalogue

| Plugin | Owns | Player verbs | Engine surface |
|---|---|---|---|
| **interactions** | Posture (sit/stand/lie/kneel), emotes, social actions, furniture interaction, `examine surroundings` | `sit stand lie kneel stretch wave shrug point smile frown laugh cry sigh nod shake dance pace greet follow reflect examine lean watch` (gametable wins `watch` via `after:` and delegates back for plain rooms) | Sets `player.posture` + `player.sittingOn` via `setLivePlayer`. Engine reacts (HP regen, stand-on-attack/move) — see [systems-posture.md](systems-posture.md). **Poker bridge:** when the room has a poker table, `sit <chair>` / `sit at the poker table` dispatches the `gametable.take_seat` action (using the chair's `seat_idx` flag) instead of posturing, and bare `sit` SIFT-prompts *floor vs the poker table* (replayed via the `interactions.sit_choice` action). No import of gametable — the coupling is purely through the action registry |
| **crafting** | Recipe display & item crafting | `craft recipes` | — |
| **factions** | Faction reputation display | `factions rep` | — |
| **mutations** | Radiation-triggered mutations | `mutations` | tick check |
| **quests** | Quest lifecycle + objective tracking | `quests quest ql` | Actions + event consumers; owns `quests`, `player_quests` tables |
| **dev-tools** | Admin/dev utilities | `.dresscyd` | admin-only |
| **container** | OPEN on containers | — | specialized action (tag-gated) |
| **fillable** | FILL/EMPTY fluid containers; DRINK from them | `fill empty` | specialized actions gated on the `fillable` capacity tag. Holds fluid amount + type in `player_inventory.custom_data`. `drink <container>` lands here; bare `drink`/`drink from <source>` falls through to the **water** plugin. Filling a non-empty unit splits it off the stack (filled = unique). Thirst-per-unit is a fluid property (`FLUID_RATES`, water=1), applied on DRINK |
| **doors** | OPEN/CLOSE/LOCK/UNLOCK | — | specialized actions (tag-gated) |
| **drugs** | USE/INJECT | — | specialized actions (tag-gated on `drug`). Delegates to engine `cmdUse` → `useDrug` (phased effects, tolerance, lethal overdose, withdrawal live in [drugs.js](../server/engine/drugs.js) + [statmods.js](../server/engine/statmods.js)). **Must forward `broadcast`** so overdose-death and hallucination teleports work. See [systems-survival.md](systems-survival.md) |
| **dealer** | Covert shadow drug-dealer access — a spoken passphrase (not a menu) opens his trust-gated shop when he's present in your zone at his dealing hours | — | Hooks `player.say` (fired from `cmdSay`). Finds a `npc_type='dealer'` NPC with `flags.covert` in the zone; a matching `flags.passphrases` entry sets `dealer_met` (first-contact gate) and dispatches `OPEN_SHOP`. Stock tiers + trust bumps live in [vendor.js](../server/engine/vendor.js) (any NPC with `flags.trust_flag` + per-entry `min_trust`). `cmdTalk` suppresses the visible "Browse your wares" for `flags.covert` NPCs. Seed: `server/models/temp/seed-dealer.js` |
| **synthesis** | Drug cooking + **splicing** — `cook` reagents into potency-scaled drugs, or `splice` (master tier) to graft multiple drugs' effects into one bespoke compound. Chemistry skill check + a "stabilize the reaction" minigame | `cook synthesize synthresolve splice splicepreview splicebegin spliceresolve` | Reuses the crafting recipe cache + 2d8−2d8 `skillCheck`. **Cook:** `cook <recipe>` validates reagents/skill/station (chem-lab furniture `flags.crafting_station='chem_lab'`, or a `cook_kit` item anywhere at −3) → `synth_minigame`; `synthresolve` (pending+TTL) folds score+station into the margin → drug with `custom_data.potency` (read by `useDrug` to scale effects + OD weight); botch = toxic damage. **Splice:** `splice` (needs Chemistry ≥6 + a real lab) opens a designer ([splicelab.js](../client/game/js/panels/splicelab.js)) — pick a base + graft instant/phases/hallucination blocks from other drugs; `splicepreview` live-computes difficulty/instability/warnings; `splicebegin` composes + launches the harder minigame; `spliceresolve` produces an **inline-effects** compound (whole composed `effects` blob on `custom_data`, no DB drug row — carrier `item_compound`/`drug_compound`). Risks: instability→bad batch, antagonistic clash→harder, overload→`dose_weight`/low OD threshold, catastrophic→lethal blowback. Consumes a dose of each source drug + a Stabilizer. `chemistry` skill in skills.js. Seed: `server/models/temp/seed-synthesis.js` |
| **trip** | Drug hallucinations — overlay trips (scripted timed events + trippy client FX, body stays attackable) and dream-zone trips (teleport to an off-map zone + an **attackable phantom body** mirroring player HP) | — | Hooks `drug.used` / `drug.overdose` fired by `useDrug`. In-memory `activeTrips`; per-trip `setTimeout` scheduler; reuses `TELEPORT` action + `spawnEnemySync`; cleans up on logout/death/overdose/restart. Client FX: `trip_start`/`trip_event`/`trip_fx`/`trip_end` messages, `[trip]` markup, `#trip-overlay` + `.tripping` CSS, inline trip audio |
| **food** | EAT | — | specialized action (tag-gated) |
| **water** | DRINK from furniture | — | specialized action gated on the `water_source` capability tag; resolves a named (or any) water-source furniture in the zone, restores thirst, else falls through to item DRINK. `wash` is owned by the **mis** plugin (it recognises `water_source`, not just `object_type='sink'`) |
| **lighting** | SWITCH/FLIP/TURN on switchable lights | — | specialized actions (tag-gated) |
| **weapon** | **Player-initiated combat**: `attack`/`kill`/`k` target resolution (enemies → NPCs → destructible infrastructure → doors → players), the player swing (`resolveAttack`/`resolveAttackNpc` — kill handling, corpse + on-corpse loot creation, `enemy.killed`/`enemy.attacked` emissions), and sleep-kills (`offlineSleepSwing`). Initiating an attack force-clears any non-standing posture. Ambiguous PvP targets replay their SIFT pick through the `ATTACK` Action (`dispatchType`/`dispatchParam` — the builtin replay path doesn't cover plugin verbs) | — | specialized actions `attack kill k` → dispatch the `ATTACK` Action; injects the auto-attack provider via `registerPlayerCombat` (engine combat.js) — gameLoop's 1s tick calls it as raw function refs, per ADR-0001. Combat *math* (`playerAttackEnemy`, `pvpSwing`, cooldowns, enemy AI) stays engine |
| **butchering** | Timed corpse carve — posture-based (`posture === "butchering"` is authoritative, companion `player.butcherState`), 5s carve, per-cut Butchering skill check, botches ruin the part and bloody the butcher | `butcher` | Registers the `BUTCHER` Action — the typed command and the engine loot router (loot on an empty-but-butcherable corpse) both dispatch it, so the loot↔butcher coupling is purely through the action registry. 1s tick completes/cleans up; `player.stop` listener; force-stand interruptions inherited from posture |
| **clothing-wetness** | Per-item wetness from rain/snow, body-temp effect | — | tick + hook |
| **weather** | Seeded 7-day forecast (type, temp, wind kph, humidity %); owns `weather_forecast` table. Daily wind rolls from the climate profile's `monthly_wind_kph` scaled by weather type + a windy/calm roll; humidity from `monthly_humidity`, driven hard by type. The engine turns temp+wind+humidity into **apparent temperature** (`getZoneApparentTemperature`, environment.js — wind chill / heat index) feeding body-temp drift and comfort messages. Also owns the drifting per-zone **weather field** (cloud/storm cells over `map_world`, drift ∝ wind; re-derived from the day's seed, no table) — injects `sampleWeatherAt(x,y)` via `registerWeatherField`; the engine samples it in `getZoneTemperature`/`getZonePrecip`/`getZoneStormIntensity`/`getZoneVisibility`. Outdoor look descriptions append wind (`getWindDescription`) and air-feel (`getAirDescription`) lines. The engine emits `weather.zoneAmbience` per occupied outdoor tile; the **audio** plugin runs precip + wind ambience beds off it, with a thunderclap duck. | — | tick (30s advect) |
| **audio** | Procedural audio runtime — asset CRUD (`audio_instruments`/`songs`/`sfx`/`ambient`/`samples`) + the event-route table; zone/SFX event playback; weather precipitation ambience beds and thunder ducking | `.createsound .playsound` (admin) | Emits WS `audio_ambience` (per-tile weather beds via `weather.zoneAmbience` 30 s tick + `zone.entered` top-up through `reconcilePlayerWeatherAmbient`, with synth fallbacks for rain/sleet/snow/blizzard) and `audio_duck` (`weather.thunder` sidechains the weather bed). Client `audio-engine.js` exposes `duckLoop(id, fraction, holdSeconds, rampSeconds)`. See [amp-format.md](amp-format.md) |
| **zone-validator** | Zone exit-connectivity integrity checks | — | startup/validation |
| **atm** | ATM terminals — power-aware, faction-networked, hackable, finite cash stock | `atm deposit withdraw jack` | USE specialized action (tag `atm`); replenish tick every 5 min. Owns `deposit`/`withdraw` outright — the matching engine `economy.js` handlers were removed |
| **bulletin** | Town-square leaderboard board — `read` it for the top 5 survivors by total XP | — | READ specialized action (furniture tag `bulletin`); ranks `bonus_xp + SUM(player_skills.ip)`, ties broken by older `created_at` |
| **shove** | Force a player or corpse into an adjacent room | `shove drag` | Contested 2d8 of actor brawn vs. target carried-weight(kg)/3 (rounded up). Validates the exit first; on success reuses engine `cmdMove` for both parties with `{bypassEncumbrance:true}` (relocates corpses via `moveCorpse`); 60 s cooldown only on failure. Player gating mirrors `attack` (forcefield apartments block) |
| **scavenging** | Perpetual, posture-based search — per-zone loot tables, the 2d8−2d8 Scavenging check, lazy weighted replenish | `scavenge` | Sets `player.posture="scavenging"` + runtime `scavengeState`; engine reads it in `describePlayerAppearance` and clears it via the usual force-stand triggers. 1s plugin tick drives 3.5s attempts. Owns `scavenging_tables`/`_items`/`_zone_stock`/`_zone_state`. See [systems-scavenging.md](systems-scavenging.md) |
| **broadcast** | Media framework — scripted channels, dynamic news, VINE graph scripts, camera feeds, NPC hosts; TV popup presentation layer | `tune watch listen tv` | USE specialized action (tag `broadcast_receiver`); broadcast tick every 5 s; event consumers (`player.death`, `flag.set`, `npc.broadcast_say`); exposes `hasChannelViewers` via broadcast-bridge for AI conditions; `tv`/`watch tv` opens in-page TV panel |
| **pinch** | Wake an offline-sleeping player and path them home; `.gohome` auto-walks a live player home then sleeps them | `pinch .gohome` | `pinch` targets offline_sleeping players with a `home_zone` not in that home — clears offline_sleeping, starts BFS walk (1 zone/min via `tick.minute` hook). `.gohome` sets `player.goingHome=true`; same hook steps them via `cmdMove {bypassEncumbrance}`; arriving puts them to sleep at home rest rates. Type `.gohome` again to cancel |
| **gametable** | Multiplayer poker (Texas Hold'em): buy-in/cash-out, 4-seat game loop, turn timers, area-pane table view | `join seat leave spectate watch look say help check call bet raise fold allin table board pot players showhand` | Owns the `game_tables` table (JSONB state, persisted every 10 s + hand end). **Verb intercepts while seated:** bare `look` pushes the poker pane instead of room HTML; `say` floats a table speech bubble then falls through; bare `help` shows poker help; `raise` falls through to the engine spend-IP verb when unseated. **`watch` router** (manifest `after:["broadcast","interactions"]` so it wins the verb): poker rooms spectate, TV rooms delegate to `broadcast.commands.watch`, both → SIFT (replay via the `gametable.watch_choice` Action), neither → `interactions.commands.watch` furniture emote. **Cross-plugin seat bridge:** exposes the `gametable.take_seat` Action so interactions' `sit` can seat players on poker chairs. Implements `zone.furniturePanel` (collapses the four chairs into one **Poker:** panel with click-to-sit seats). Dealer narration/banter, denominated ₵ bet animations, and procedural sound cues (`poker_sfx` → `client/game/js/poker-sfx.js`) — detail in `plugins/gametable/` |

| **mis** | Mature Interaction System — opt-in sexual verbs, horniness/arousal, ongoing events, climax, `wash`, MIS-gated appearance notes | `mis touch grope squeeze kiss lick fondle slap stroke masturbate jerkoff jackoff rubself fingerself suck fuck sex screw rail bang breed blowjob bj handjob hj ejaculate cum come wash` + input matchers `jerk off on` / `eat out` | The engine keeps only the **consent substrate** (`server/engine/mis.js`: `isMisActive`/`isAttractedTo` + server setting) — read by bodily, appearance rendering, MORPHEX. Plugin implements the `player.appearanceMisNotes` hook (describePlayerAppearance fires it at its naked/clothed sites), consumes `player.stop` (halts ongoing events) and `mis.toggled` (WS Maturity-Slider toggle → tutorial / event cleanup), and runs horniness decay on a `1m` tick. State module: `plugins/mis/mis-system.js` |
| **thievery** | Pocket-picking live players | `steal` | Deception check vs. 7; 60 s cooldown persisted in the Flag store (`steal_cooldown_until`) so it survives restarts; SIFT ambiguous picks replay via the `thievery.steal` Action |
| **bodily** | Bowel/bladder pressure, involuntary release, relief verbs, toilet/sink `use` panels | `pee urinate piss poop defecate shit flush` | 1m tick (skips sleeping players, mirroring the old engine tick); self-gated `use` specialized action for toilet/sink panels; SIFT on-player picks replay via `bodily.pee_target`/`bodily.poop_target` Actions. **Stains and digestion loads stay engine** (`server/engine/bodily.js` substrate: `stainClothing`/`stainZone`/`foodLoad`/`drinkLoad`/`applyThirst` — written/read by mis, butchering, drugs, water, fillable, inventory) |
| **commerce** | Vendor shopping verbs + balance display | `shop browse buy sell balance` | Thin verb layer over the engine vendor services (vendor.js pricing/trust/stock, furniture-shop.js, vendor-session.js — all stay engine); SIFT picks replay via `commerce.shop_vendor`/`commerce.buy_item` Actions |
| **emergency** | Emergency Security Protocol — zone-wide siren, warning broadcasts, red-alert UI | — | hooks `furniture.describe` + `player.death`; routes at `/emergency` |
| **knock** | Knock on a door in a direction; heard only in the adjacent same-floor room | `knock` | — |
| **surveillance** | SPECTER — player spy networks + witnessed-crime wanted system (0–5 stars, police tiers up to Arbiters, evidence + bounties) | `plant retrieve sweep feed hub record clip replay smash hijack pilot submit wanted bribe scrub …` | USE specialized actions on `spy_deck`/`security_console`/`datachip` tags; see [systems-surveillance.md](systems-surveillance.md) |
| **vendor-safe** | Hackable vendor safes storing accumulated sale credits | `hack` | Crack the rotating frequency lock to drain them |
| **cosmetic-machine** | MORPHEX 9000 BioSculpt terminal | `morphex makeover biosculpt` | Self-gated `use` specialized action (machine names); engine furniture router opens the panel via the `cosmetic.open` Action |

A plugin with no player verbs and no specialized actions integrates purely through **hooks**
(request/response into engine flows) or **ticks** (scheduler cadences).

## When a system spans engine and plugin

Some mechanics are split: a plugin owns the **state** (what the player typed sets it) and the engine
owns the **reactions** (loops, combat, movement that read it). Posture is the canonical example. When
that happens, the plugin and engine **must agree on the field name and shape** — a mismatch makes one
half silently dead. Document the contract in the relevant `docs/systems-*.md` and run the
[source-of-truth audit](audits/source-of-truth-audit.md) when in doubt.
