import { handlers as moveHandlers } from './movement.js';
import { handlers as combatHandlers } from './combat.js';
import { handlers as invHandlers } from './inventory.js';
import { handlers as socialHandlers } from './social.js';
import { handlers as housingHandlers } from './housing.js';
import { handlers as worldHandlers } from './world.js';
import { fireCommand, fireInputMatchers } from '../plugins.js';
import { deactivateForcefield } from '../apartments.js';
import { fireSpecializedAction } from '../specializedActions.js';
import { getSelectionState, advanceSelectionState, formatSelectionPage } from '../sift.js';
import { getLivePlayer } from '../world.js';
import { emit } from '../events.js';
import { setPosture } from '../posture.js';

export { describeZone, describeVoidTeleport } from './describe.js';
export { recomputeArmor, recomputeInsulation, EQUIP_SLOTS } from './inventory.js';

const builtins = new Map([
  ...Object.entries(moveHandlers),
  ...Object.entries(combatHandlers),
  ...Object.entries(invHandlers),
  ...Object.entries(socialHandlers),
  ...Object.entries(housingHandlers),
  ...Object.entries(worldHandlers),
]);

// Unified STOP: one verb ends every ongoing/recurring action at once — combat,
// following, and (via the player.stop event) every plugin's repeating actions
// (scavenging, butchering, MIS events, …).
async function cmdStopAll(args, raw, player, broadcast) {
  const stopped = [];

  if (player.combatTargetId || player.pvpTargetId || player.npcCombatTargetId) {
    if (player.pvpTargetId) {
      const opponent = getLivePlayer(player.pvpTargetId);
      if (opponent) {
        opponent.pvpTargetId = null;
        broadcast(null, { type: 'output', message: `${player.handle} disengages. Combat ends.` }, null, opponent.id);
      }
    }
    player.combatTargetId = null;
    player.pvpTargetId = null;
    player.npcCombatTargetId = null;
    // Grace window so enemy/NPC retaliation and aggro don't instantly re-arm our
    // target on the next combat tick — long enough to actually break off and flee.
    player.disengagedUntil = Date.now() + 6000;
    stopped.push('fighting');
  }

  if (player.following) {
    player.following = null;
    stopped.push('following');
  }

  // Let plugins halt their own repeating actions (e.g. scavenging). Synchronous
  // subscribers push a label onto `stopped` before this returns.
  emit('player.stop', { player, broadcast, stopped });

  if (!stopped.length) return { type: 'output', message: "You aren't doing anything to stop." };
  return { type: 'output', message: `You stop ${stopped.join(', ')}.` };
}

builtins.set('stop', cmdStopAll);
builtins.set('disengage', cmdStopAll);

// Engine verb names, exposed so the plugin loader can report which builtins
// are shadowed by plugin-registered verbs (dispatch order makes those dead).
export function builtinCommandNames() { return [...builtins.keys()]; }

export async function handleCommand(input, player, broadcast) {
  const raw = input.trim();
  if (!raw) return null;

  // SIFT selection-state intercept — runs before all routing.
  const _sel = getSelectionState(player.id);
  if (_sel) {
    const adv = advanceSelectionState(player.id, raw);
    if (!adv) {
      // State expired — fall through to normal pipeline
    } else if (adv.type === 'cancel') {
      return { type: 'output', message: 'Selection cancelled.' };
    } else if (adv.type === 'page') {
      return { type: 'output', message: formatSelectionPage(adv.state) };
    } else if (adv.type === 'selected') {
      const { verb, dispatchType, dispatchParam } = _sel.context;
      if (dispatchType && dispatchParam) {
        const { dispatchAction } = await import('../actions.js');
        return dispatchAction({
          type: dispatchType,
          actor: player,
          params: { [dispatchParam]: adv.candidate },
          context: { broadcast },
        });
      }
      const handler = builtins.get(verb);
      if (handler) return handler([adv.candidate.name.toLowerCase()], `${verb} ${adv.candidate.name}`, player, broadcast);
      return { type: 'error', message: 'Selection handler lost.' };
    }
    // adv.type === 'refine': fall through — treat as fresh command
  }

  const parts = raw.toLowerCase().split(/\s+/);
  const cmd = parts[0];
  const args = parts.slice(1);

  if (player.sleeping && cmd !== 'sleep' && cmd !== 'rest') {
    const wasHome = player.sleeping.reason === 'home';
    player.sleeping = null;
    setPosture(player, 'standing');
    const WAKE_MESSAGES = [
      'jolts awake, eyes wild.',
      'snaps awake with a grunt.',
      'wakes with a start, disoriented.',
      'lurches upright, suddenly conscious.',
      'stirs and opens their eyes.',
    ];
    const roomMsg = WAKE_MESSAGES[Math.floor(Math.random() * WAKE_MESSAGES.length)];
    broadcast(player.current_zone, { type: 'zone_event', message: `${player.handle} ${roomMsg}` }, player.id);
    if (wasHome) await deactivateForcefield(player.id, player.home_zone, broadcast);
    const result = await handleCommand(input, player, broadcast);
    if (result) result.message = `You wake up.\n\n${result.message ?? ''}`.trimEnd();
    return result;
  }

  // Multi-word verbs (engine and plugin) — first matching pattern wins.
  const matcherResult = await fireInputMatchers(args, raw, player, broadcast);
  if (matcherResult !== undefined) return matcherResult;

  const pluginResult = await fireCommand(cmd, args, raw, player, broadcast);
  if (pluginResult !== undefined) return pluginResult;

  // Tag-gated specialized actions (doors, containers, food, weapons, …). Each
  // handler self-resolves its target and returns undefined to fall through to
  // the built-in handler below — keeping every verb playable mid-port.
  const specialResult = await fireSpecializedAction(cmd, args, raw, player, broadcast);
  if (specialResult !== undefined) return specialResult;

  const handler = builtins.get(cmd);
  if (handler) return handler(args, raw, player, broadcast);
  return { type:'error', message:`Unknown command: "${cmd}". Type HELP for commands.` };
}
