import { query } from '../../models/db.js';
import { getZone, getZoneEnemies, getZoneNpcs, getZonePlayers, getDoorForExit, getZoneDoors, spawnEnemySync, world } from '../world.js';
import { getLockTagPublic } from './doors.js';
import { getZonePowerStatus, recomputePower, recalcZoneLoad, getEnvironmentState } from '../environment.js';
import { getPlayerSkills, SKILLS } from '../skills.js';
import { describeZone } from './describe.js';
import { getMinimapData, addPlayerToZone, removePlayerFromZone } from '../world.js';
import { statCost, raiseStat, RAISABLE_STATS } from '../ip.js';
import { ensureTunables } from '../tunables.js';
import { physicalDescription, ejaculateDescription, describeGenitals } from '../appearance.js';
import { isMisActive, isAttractedTo, addHorniness, erectionVisibilityNote, breastVisibilityNote, NIPPLE_HARD, NIPPLE_SOFT } from '../mis.js';
import { availableActions } from '../specializedActions.js';
import { statusLabels } from '../effects.js';

async function cmdStats(player) {
  const { rows } = await query('SELECT * FROM players WHERE id=$1', [player.id]);
  const p = rows[0];
  if (!p) return { type:'error', message:'Could not load stats.' };
  const radBar = `[${'█'.repeat(Math.floor(p.radiation/10))}${'░'.repeat(10-Math.floor(p.radiation/10))}]`;
  let msg = `<span class="stats-header">${p.handle}</span> — ${p.archetype||'unknown'}\n\n`;
  msg += `HP:     ${p.hp}/${p.hp_max}\nSanity: ${p.sanity}/${p.sanity_max}\nHunger: ${p.hunger}/100\nThirst: ${p.thirst}/100\nRAD:    ${radBar} ${p.radiation}/100\n\n`;
  msg += `BRAWN:${p.stat_brawn}  REFL:${p.stat_reflexes}  BRNS:${p.stat_brains}\nCOOL:${p.stat_cool}  END:${p.stat_endurance}\n\nIP: ${p.ip||0}  Credits: ${p.credits}`;

  const statusFlags = [];
  if (player.sleeping) statusFlags.push('Asleep');
  if (player.healOverTime?.length) statusFlags.push(`Healing (${player.healOverTime.reduce((s,h)=>s+h.perTick*h.ticksRemaining,0)} HP over ${Math.max(...player.healOverTime.map(h=>h.ticksRemaining))}m)`);
  if (player.wellFedUntil && Date.now() < player.wellFedUntil) statusFlags.push('Well-Fed');
  if (player.hydratedUntil && Date.now() < player.hydratedUntil) statusFlags.push('Hydrated');
  if (p.covered_in_blood) statusFlags.push('Covered in blood');
  statusFlags.push(...statusLabels(player));
  if (statusFlags.length) msg += `\n\n<span class="status-flags">${statusFlags.join(' · ')}</span>`;

  return { type:'stats', message:msg, player:p };
}

async function cmdSkills(player) {
  const skills = await getPlayerSkills(player.id);
  let msg = '<span class="skills-header">SKILLS</span>\n\n';
  for (const cat of ['combat','survival','tech','social','arcane']) {
    msg += `<span class="skill-category">${cat.toUpperCase()}</span>\n`;
    for (const skill of Object.values(SKILLS).filter(s=>s.category===cat)) {
      const data = skills[skill.id] || { trained:0 };
      const bars = Math.min(10, Math.round(data.trained));
      msg += `  ${skill.name.padEnd(20)} [${'█'.repeat(bars)}${'░'.repeat(10-bars)}] ${data.trained.toFixed(2)}/10\n`;
    }
    msg += '\n';
  }
  return { type:'skills', message:msg };
}

const BODY_SLOTS = ['head','torso','hands','legs','feet'];
// Returns name lowercased, preceded by "a"/"an" unless the last word is plural (ends in s, not ss).
function withArticle(name) {
  const n = name.toLowerCase();
  const lastWord = n.trim().split(/\s+/).pop();
  if (/s$/i.test(lastWord) && !/ss$/i.test(lastWord)) return n;
  return (/^[aeiou]/.test(n) ? 'an ' : 'a ') + n;
}

async function describePlayerAppearance(target, isSelf, viewer = null, broadcast = null) {
  const { rows: equipped } = await query(
    `SELECT i.name, i.tags FROM player_inventory pi
     JOIN items i ON i.id = pi.item_id
     WHERE pi.player_id=$1 AND pi.is_equipped=1`,
    [target.id]
  );

  // Count items per slot (for erection layer visibility)
  const layerCounts = {};
  // For each body slot, pick the outermost equipped item (highest allowed_layer_range.max).
  const bySlot = {};
  for (const row of equipped) {
    const slot = row.tags?.slot;
    if (!slot) continue;
    layerCounts[slot] = (layerCounts[slot] || 0) + 1;
    const lr = row.tags?.allowed_layer_range;
    const layerMax = (lr && typeof lr === 'object') ? (lr.max || 0) : 99;
    if (!bySlot[slot] || layerMax > bySlot[slot].layerMax) {
      bySlot[slot] = { name: row.name, layerMax, tags: row.tags };
    }
  }

  const handle = target.handle;
  const origin = target.origin_fragment || '';
  const mutated = target.visibly_mutated;

  const bodyPieces = BODY_SLOTS.filter(s => bySlot[s]).map(s =>
    `${withArticle(bySlot[s].name)} on ${isSelf ? 'your' : 'their'} ${s}`
  );
  const weapon = bySlot['weapon_hand'];
  const accessory = bySlot['accessory'];

  // Physical appearance line (new)
  const physLine = physicalDescription(target, isSelf);

  const DEFAULT_ORIGIN = 'A survivor. Still standing, somehow.';
  let msg = `${origin || DEFAULT_ORIGIN}\n`;
  if (physLine) msg += `${physLine}\n`;
  if (mutated) msg += `<span class="mutation-tag">Something about ${isSelf ? 'you' : 'them'} isn't quite human anymore.</span>\n`;
  if (target.covered_in_blood) msg += `<span style="color:var(--red)">${isSelf ? 'You are' : 'They are'} covered in blood.</span>\n`;

  // Clothing contamination
  const contamination = target.clothing_contamination || {};
  const stainedSlots = Object.keys(contamination).filter(k => contamination[k] && bySlot[k]);
  if (stainedSlots.length) {
    const slotList = stainedSlots.map(s => `${bySlot[s].name} (${s})`).join(', ');
    msg += `<span style="color:var(--red)">Stained: ${slotList}.</span>\n`;
  }

  if (!bodyPieces.length && !weapon && !accessory) {
    const nakedLines = isSelf
      ? [
          `You have nothing on. Not a thread. You are, in the technical sense, naked.`,
          `You're wearing exactly nothing. It's a look. A bold one.`,
          `You are completely undressed. Whether that's a statement or an oversight isn't clear.`,
        ]
      : [
          `${handle} is wearing nothing. Absolutely nothing. You respect the commitment.`,
          `${handle} has nothing on. Not a stitch. You make a note of this and move on.`,
          `${handle} is completely undressed. They seem unbothered by it.`,
        ];
    msg += nakedLines[Math.floor(Math.random() * nakedLines.length)];

    // MIS details when naked — gated on viewer's MIS (or self's MIS for self-look)
    const viewerForMis = isSelf ? target : (viewer || null);
    if (viewerForMis && isMisActive(viewerForMis)) {
      const envState = getEnvironmentState();
      const genitalDesc = describeGenitals(target, isSelf);
      if (genitalDesc) msg += `\n${genitalDesc}`;
      const ejacNote = ejaculateDescription(target, isSelf, new Set());
      if (ejacNote) msg += `\n${ejacNote}`;
      if (target.biological_sex === 'female') {
        const hard = (target.horniness || 0) >= 65 || (envState.tempC !== undefined && envState.tempC < 10);
        const pool = hard ? NIPPLE_HARD : NIPPLE_SOFT;
        msg += `\n${pool[Math.floor(Math.random() * pool.length)]}`;
      }
    }

    // Arousal on examine: viewer sees naked target they're attracted to
    if (!isSelf && viewer && isMisActive(viewer) && isAttractedTo(viewer, target) && broadcast) {
      const arouseMsgs = await addHorniness(viewer, 8, broadcast);
      if (arouseMsgs.length) broadcast(null, { type:'resource_tick', messages: arouseMsgs, player_update: { horniness: viewer.horniness } }, null, viewer.id);
    }

    return msg.trim();
  }

  const sentences = [];
  let namedUsed = false;

  // First sentence uses "Name is ...", subsequent use "They are ..." / "You are ..."
  function subject(nameVerb, theyVerb, youVerb) {
    if (isSelf) return youVerb;
    if (!namedUsed) { namedUsed = true; return `${handle} ${nameVerb}`; }
    return theyVerb;
  }

  const cap = s => s.charAt(0).toUpperCase() + s.slice(1);

  if (bodyPieces.length) {
    sentences.push(cap(`${subject('is wearing', 'they are wearing', 'you are wearing')} ${bodyPieces.join(', ')}.`));
  }

  if (weapon) {
    sentences.push(cap(`${subject('is carrying', 'they are carrying', 'you are carrying')} ${withArticle(weapon.name)}.`));
  }

  if (accessory) {
    const place = isSelf ? 'on you' : 'on them';
    sentences.push(cap(`${subject('has', 'they have', 'you have')} ${withArticle(accessory.name)} ${place}.`));
  }

  msg += sentences.join(' ');

  // MIS-gated details for clothed players — all gated on viewer's (or self's) MIS
  const coveredSlots = new Set(Object.keys(bySlot));
  const viewerMis = isSelf ? isMisActive(target) : (viewer && isMisActive(viewer));
  if (viewerMis) {
    const ejacNote = ejaculateDescription(target, isSelf, coveredSlots);
    if (ejacNote) msg += `\n${ejacNote}`;
    const envState = getEnvironmentState();
    // Erection visible through ≤3 layers of tight clothing
    const tightSlots = new Set(
      Object.entries(bySlot).filter(([,v]) => v.tags?.bulkiness <= 2).map(([k]) => k)
    );
    const legsLayerCount = layerCounts['legs'] || 0;
    const erectNote = erectionVisibilityNote(target, tightSlots, legsLayerCount);
    if (erectNote) msg += `\n${erectNote}`;

    // Breast/nipple visibility for females
    const torsoLayerCount = layerCounts['torso'] || 0;
    const torsoItem = bySlot['torso'];
    const outermostBulkiness = torsoItem?.tags?.bulkiness || 0;
    const outermostLayerMax = torsoItem?.tags?.allowed_layer_range?.max ?? 99;
    const breastNote = breastVisibilityNote(target, torsoLayerCount, outermostBulkiness, outermostLayerMax, torsoItem?.name, envState.tempC);
    if (breastNote) msg += `\n${breastNote}`;

    // Arousal on examine: visible erection or nipples on attracted viewer
    if (!isSelf && viewer && isMisActive(viewer) && isAttractedTo(viewer, target) && broadcast) {
      const visibleSex = erectNote || breastNote;
      if (visibleSex) {
        const arouseMsgs = await addHorniness(viewer, 5, broadcast);
        if (arouseMsgs.length) broadcast(null, { type:'resource_tick', messages: arouseMsgs, player_update: { horniness: viewer.horniness } }, null, viewer.id);
      }
    }
  }

  return msg.trim();
}

async function cmdExamine(targetStr, player, broadcast) {
  if (!targetStr || targetStr === 'room') {
    const zone = getZone(player.current_zone);
    if (!zone) return { type:'error', message:'You are nowhere. This is a bug.' };
    return { type:'look', message: await describeZone(zone, player), zone: zone.id, minimap: getMinimapData(player.current_zone) };
  }

  const t = targetStr.toLowerCase();

  // Self-look
  if (t === 'me' || t === 'myself' || t === 'self') {
    return { type:'examine', message: await describePlayerAppearance(player, true, player, broadcast) };
  }

  const { rows } = await query(`SELECT pi.id AS inv_id, i.* FROM player_inventory pi JOIN items i ON i.id=pi.item_id WHERE pi.player_id=$1 AND pi.container_id IS NULL AND i.name ILIKE $2 LIMIT 1`, [player.id, `%${targetStr}%`]);
  if (rows.length) {
    const it = rows[0];
    let msg = `${it.name}\n${it.description}`;
    if (it.tags && Object.prototype.hasOwnProperty.call(it.tags, 'container')) {
      const { describeContainer } = await import('./inventory.js');
      msg += `\n\n${await describeContainer({ id: it.inv_id, name: it.name, tags: it.tags })}`;
    }
    const acts = availableActions(it);
    if (acts.length) {
      const links = acts.map(v =>
        `<span class="action-link" data-action="${v}" data-target="${it.name}">${v}</span>`
      ).join('  ');
      msg += `\n<span class="text-dim">Actions:</span> ${links}`;
    }
    return { type:'examine', message: msg };
  }
  const { rows: furnitureRows } = await query(`SELECT * FROM furniture WHERE zone_id=$1 AND name ILIKE $2 LIMIT 1`, [player.current_zone, `%${targetStr}%`]);
  if (furnitureRows.length) {
    const f = furnitureRows[0];
    let msg = `${f.name}\n${f.description}`;
    const interactions = f.flags?.interactions || [];
    if (f.object_type === 'light') {
      if (f.light_type === 'streetlight') {
        msg += `\n<span class="light-state ${f.light_on ? 'light-on' : 'light-off'}">Currently ${f.light_on ? 'lit' : 'dark'} — city-grid controlled, no switch out here.</span>`;
      } else {
        msg += `\n<span class="light-state ${f.light_on ? 'light-on' : 'light-off'}">Currently ${f.light_on ? 'on' : 'off'}.</span>`;
        if (interactions.includes('switch')) {
          const n = f.name.toLowerCase();
          const stateDir = f.light_on ? 'off' : 'on';
          const switchLink = `<span class="action-link" data-action="switch" data-target="${stateDir} ${n}">switch ${stateDir}</span>`;
          const turnLink = `<span class="action-link" data-action="turn" data-target="${stateDir} ${n}">turn ${stateDir}</span>`;
          msg += `\n<span class="text-dim">Actions:</span> ${switchLink}  ${turnLink}`;
        }
      }
    } else if (f.object_type === 'container') {
      const n = f.name.toLowerCase();
      const openLink = `<span class="action-link" data-action="open" data-target="${n}">open</span>`;
      msg += `\n<span class="text-dim">Actions:</span> ${openLink}`;
    } else if (interactions.length) {
      const links = interactions.map(ix =>
        `<span class="action-link" data-action="${ix}" data-target="on ${f.name.toLowerCase()}">${ix}</span>`
      ).join('  ');
      msg += `\n<span class="text-dim">Actions:</span> ${links}`;
    }
    return { type:'examine', message: msg };
  }
  const matchAnyGenerator = /generator/i.test(targetStr);
  const { rows: generatorRows } = await query(
    `SELECT * FROM generators WHERE zone_id=$1 AND ($2 OR name ILIKE $3) LIMIT 1`,
    [player.current_zone, matchAnyGenerator, `%${targetStr}%`]
  );
  if (generatorRows.length) {
    const gen = generatorRows[0];
    const { rows: loadRows } = await query(
      `SELECT COALESCE(SUM(current_load_kw),0)::float AS total_load, COUNT(*)::int AS zone_count FROM power_zones WHERE generator_id=$1`,
      [gen.id]
    );
    const totalLoad = loadRows[0]?.total_load || 0;
    const zoneCount = loadRows[0]?.zone_count || 0;
    const statusLabel = gen.status === 'online' ? 'RUNNING' : gen.status.toUpperCase();
    const typeLabel = gen.generator_type === 'city_plant' ? 'city power plant' : gen.generator_type === 'building' ? 'building generator' : 'portable generator';
    let msg = `${gen.name || 'Generator'}\nA permanent ${typeLabel}. No fuel required — it just runs.\n\n` +
      `STATUS: ${statusLabel}\nOUTPUT: ${gen.capacity_kw}kW capacity, ${totalLoad}kW current draw\n` +
      `SERVING: ${zoneCount} zone${zoneCount === 1 ? '' : 's'}`;
    if (totalLoad > gen.capacity_kw) msg += `\n<span class="generator-overload">⚠ OVERLOADED — drawing more than rated capacity.</span>`;
    return { type:'examine', message: msg };
  }
  const enemies = getZoneEnemies(player.current_zone);
  const enemy = enemies.find(e=>e.name.toLowerCase().includes(t));
  if (enemy) return { type:'examine', message:`${enemy.name}\n${enemy.description}\nHP: ${enemy.hp}/${enemy.hp_max}` };
  const npcs = getZoneNpcs(player.current_zone);
  const npc = npcs.find(n=>n.name.toLowerCase().includes(t));
  if (npc) return { type:'examine', message:`${npc.name}\n${npc.description}` };

  // Other players in zone + sleeping
  const others = getZonePlayers(player.current_zone).filter(p => p.id !== player.id);
  const targetPlayer = others.find(p => p.handle.toLowerCase().includes(t));
  if (targetPlayer) {
    return { type:'examine', message: await describePlayerAppearance(targetPlayer, false, player, broadcast) };
  }
  const { rows: sleepers } = await query(
    `SELECT * FROM players WHERE LOWER(handle) LIKE $1 AND current_zone=$2 AND offline_sleeping=TRUE LIMIT 1`,
    [`%${t}%`, player.current_zone]
  );
  if (sleepers.length) {
    const s = sleepers[0];
    const app = await describePlayerAppearance(s, false, player, broadcast);
    return { type:'examine', message: app + `\n<span class="text-dim">(${s.handle} is asleep.)</span>` };
  }

  // Door examination: "examine door", "examine north", "examine door north", "examine north door"
  const EXAM_DIRS = ['north','south','east','west','up','down','in','out'];
  const EXAM_OPP  = { north:'south', south:'north', east:'west', west:'east', up:'down', down:'up', in:'out', out:'in' };

  function describeDoor(examDoor, dirHint) {
    const lockTag  = getLockTagPublic(examDoor);
    const hpLine   = examDoor.hp <= 0 ? 'destroyed' : `${examDoor.hp}/${examDoor.hp_max} HP`;
    const stateStr = examDoor.hp > 0 ? (examDoor.is_open ? 'open' : 'closed') : '';
    const lockStr  = lockTag
      ? ` · ${lockTag.type.replace('lock:', '')} [${examDoor.lock_state ?? 'no state'}]`
      : ' · no lock';
    let msg = `${examDoor.name || 'Door'} (${examDoor.door_type})\n${hpLine}${stateStr ? `, ${stateStr}` : ''}${lockStr}`;
    const acts = examDoor.hp > 0 ? ['open', 'close'] : [];
    if (lockTag && examDoor.hp > 0) acts.push('lock', 'unlock');
    if (!lockTag && examDoor.hp > 0) acts.push('install');
    if (lockTag && examDoor.hp > 0) acts.push('uninstall');
    if (acts.length && dirHint) {
      const links = acts.map(v => `<span class="action-link" data-action="${v}" data-target="door ${dirHint}">${v}</span>`).join('  ');
      msg += `\n<span class="text-dim">Actions:</span> ${links}`;
    }
    return { type: 'examine', message: msg };
  }

  const examDir = EXAM_DIRS.find(d => t === d || t === `door ${d}` || t === `${d} door`);
  if (examDir) {
    const zone = getZone(player.current_zone);
    let examDoor = getDoorForExit(player.current_zone, examDir);
    if (!examDoor) {
      const targetId = zone?.exits?.[examDir];
      if (targetId) examDoor = getDoorForExit(targetId, EXAM_OPP[examDir]) || null;
    }
    if (examDoor) return describeDoor(examDoor, examDir);
  }

  if (t === 'door') {
    const zone = getZone(player.current_zone);
    const local = getZoneDoors(player.current_zone);
    const farSide = [];
    for (const [dir, targetId] of Object.entries(zone?.exits || {})) {
      const d = getDoorForExit(targetId, EXAM_OPP[dir]);
      if (d && !local.find(x => x.id === d.id)) farSide.push({ door: d, dir });
    }
    const localWithDir = local.map(d => ({ door: d, dir: d.exit_dir }));
    const all = [...localWithDir, ...farSide];
    if (all.length === 1) return describeDoor(all[0].door, all[0].dir);
    if (all.length > 1) {
      const dirs = all.map(e => e.dir).join(', ');
      return { type: 'error', message: `Multiple doors here — specify a direction (${dirs}).` };
    }
  }

  return { type:'error', message:`You don't see "${targetStr}" here.` };
}

async function cmdSpawn(args, player) {
  if (!['admin', 'dev'].includes(player.role)) return { type: 'error', message: 'Access denied.' };
  const [itemId, zoneArg] = args;
  if (!itemId) return { type: 'error', message: 'Usage: spawn <item_id> [zone_id|here]' };
  const zoneId = (!zoneArg || zoneArg === 'here') ? player.current_zone : zoneArg;
  const { rows } = await query('SELECT id FROM items WHERE id=$1', [itemId]);
  if (!rows.length) return { type: 'error', message: `No item "${itemId}".` };
  const invId = `inv_spawn_${Date.now()}`;
  await query('INSERT INTO player_inventory (id,player_id,item_id,quantity) VALUES ($1,$2,$3,1)',
    [invId, `_ground_${zoneId}`, itemId]);
  return { type: 'output', message: `Spawned ${itemId} in ${zoneId}.` };
}

async function cmdSpawnEnemy(args, player) {
  if (!['admin', 'dev'].includes(player.role)) return { type: 'error', message: 'Access denied.' };
  const [enemyId, zoneArg] = args;
  if (!enemyId) return { type: 'error', message: 'Usage: spawnenemy <enemy_id> [zone_id|here]' };
  const zoneId = (!zoneArg || zoneArg === 'here') ? player.current_zone : zoneArg;
  if (!world.zones.get(zoneId)) return { type: 'error', message: `Zone "${zoneId}" is not loaded.` };
  const { rows } = await query('SELECT * FROM enemies WHERE id=$1', [enemyId]);
  if (!rows.length) return { type: 'error', message: `No enemy template "${enemyId}".` };
  const instance = spawnEnemySync(rows[0], zoneId);
  return { type: 'output', message: `Spawned ${instance.name} (${instance.instanceId}) in ${zoneId}.` };
}

async function applyLightSwitch(nameStr, dir, player) {
  if (!nameStr) return { type:'error', message:'Specify a light name.' };
  const { rows } = await query(`SELECT * FROM furniture WHERE zone_id=$1 AND object_type='light' AND name ILIKE $2 LIMIT 1`, [player.current_zone, `%${nameStr}%`]);
  if (!rows.length) return { type:'error', message:`You don't see a light called "${nameStr}" here.` };
  const light = rows[0];
  if (light.light_type === 'streetlight') {
    return { type:'error', message:`${light.name} is city-grid infrastructure — it comes on by itself once it gets dark. There's no switch out here.` };
  }
  const newState = dir ? (dir === 'on' ? 1 : 0) : (light.light_on ? 0 : 1);
  if (light.light_on === newState) {
    return { type:'message', message:`${light.name} is already ${newState ? 'on' : 'off'}.` };
  }
  const powerStatus = getZonePowerStatus(player.current_zone);
  if (powerStatus === 'unpowered' && newState === 1) {
    return { type:'error', message:`The switch clicks, but nothing happens. No power reaches this room.` };
  }
  await query(`UPDATE furniture SET light_on=$1 WHERE id=$2`, [newState, light.id]);
  const { rows: countRows } = await query(
    `SELECT COUNT(*)::int AS cnt, COALESCE(SUM(COALESCE(lumen_output,0)),0)::int AS lm FROM furniture WHERE zone_id=$1 AND object_type='light' AND light_on=1`,
    [player.current_zone]
  );
  await query(`UPDATE lighting_states SET fixture_count=$1, total_lumens=$2 WHERE zone_id=$3`, [countRows[0]?.cnt || 0, countRows[0]?.lm || 0, player.current_zone]).catch(()=>{});
  await recalcZoneLoad(query, player.current_zone).catch(()=>{});
  await recomputePower().catch(()=>{});
  const flipMsg = newState
    ? `You flip the switch. ${light.name} flickers on.`
    : `You flip the switch. ${light.name} goes dark.`;
  const zone = getZone(player.current_zone);
  const lookMsg = await describeZone(zone, player);
  return { type:'look', message:`${flipMsg}\n\n${lookMsg}`, zone: player.current_zone, minimap: getMinimapData(player.current_zone) };
}

// "switch on/off <name>" or "switch <name> on/off" or "switch <name>" (toggle)
async function cmdSwitch(targetStr, player) {
  if (!targetStr) return { type:'error', message:'Usage: switch on/off <light name>' };
  const words = targetStr.split(' ');
  const first = words[0].toLowerCase();
  const last  = words[words.length - 1].toLowerCase();
  let dir = null;
  let nameStr;
  if (first === 'on' || first === 'off') {
    dir = first;
    nameStr = words.slice(1).join(' ');
  } else if (last === 'on' || last === 'off') {
    dir = last;
    nameStr = words.slice(0, -1).join(' ');
  } else {
    nameStr = targetStr; // no direction — toggle
  }
  return applyLightSwitch(nameStr, dir, player);
}

// "turn on/off <name>" or "turn <name> on/off"
async function cmdTurn(args, player) {
  const first = args[0]?.toLowerCase();
  const last  = args[args.length - 1]?.toLowerCase();
  let dir, nameStr;
  if (first === 'on' || first === 'off') {
    dir = first;
    nameStr = args.slice(1).join(' ');
  } else if (last === 'on' || last === 'off') {
    dir = last;
    nameStr = args.slice(0, -1).join(' ');
  } else {
    return { type:'error', message:'Usage: turn on/off <light name> — or — turn <light name> on/off' };
  }
  return applyLightSwitch(nameStr, dir, player);
}

async function cmdTeleport(targetZoneId, player, broadcast) {
  if (player.role !== 'admin') return { type:'error', message:"You don't have the clearance for that." };
  if (!targetZoneId) return { type:'error', message:'Teleport where? Usage: teleport <zone id>' };
  const targetZone = getZone(targetZoneId);
  if (!targetZone) return { type:'error', message:`No zone with id "${targetZoneId}" exists.` };

  const oldZoneId = player.current_zone;
  removePlayerFromZone(player.id, oldZoneId);
  addPlayerToZone(player.id, targetZoneId);
  player.current_zone = targetZoneId;
  await query('UPDATE players SET current_zone=$1 WHERE id=$2', [targetZoneId, player.id]);

  broadcast(oldZoneId, { type:'zone_event', message:`${player.handle} vanishes in a flicker of static.` }, player.id);
  broadcast(targetZoneId, { type:'zone_event', message:`${player.handle} flickers into existence out of nowhere.` }, player.id);

  return { type:'move', message: await describeZone(targetZone, player), zone: targetZoneId, minimap: getMinimapData(targetZoneId) };
}

function cmdHelp(player) {
  let msg = `<span class="help-header">COMMANDS</span>

<span class="help-category">MOVEMENT</span>    north south east west up down (n/s/e/w/u/d)  |  go &lt;dir&gt;
<span class="help-category">COMBAT</span>      attack &lt;target&gt;  |  loot &lt;corpse&gt;
<span class="help-category">ITEMS</span>       inventory  take &lt;item&gt;  drop  use  equip
<span class="help-category">CONTAINERS</span>  look in &lt;container&gt;  |  stow &lt;item&gt; in &lt;container&gt;  |  pull &lt;item&gt; from &lt;container&gt;
<span class="help-category">CRAFTING</span>    recipes  |  craft &lt;recipe_id&gt;
<span class="help-category">TRADING</span>     shop &lt;npc&gt;  |  buy &lt;item&gt;  |  sell &lt;item&gt;
<span class="help-category">ECONOMY</span>     balance  |  deposit &lt;amt/all&gt;  |  withdraw &lt;amt/all&gt;  (ATM required)  |  steal &lt;player&gt;
<span class="help-category">PROPERTY</span>    rent  |  lock  |  unlock  |  pick  |  upgrade lock  |  sleep
<span class="help-category">CHARACTER</span>   stats  skills  raise [stat]  mutations  factions
<span class="help-category">SOCIAL</span>      talk &lt;npc&gt;  |  say &lt;message&gt;  |  who  |  whisper/tell &lt;player&gt; &lt;msg&gt;
<span class="help-category">WORLD</span>       map  |  switch on/off &lt;light&gt;  |  turn on/off &lt;light&gt;
<span class="help-category">POSTURE</span>     sit  |  sit on &lt;furniture/floor&gt;  |  lie  |  lie on &lt;furniture&gt;  |  kneel  |  stand
<span class="help-category">EMOTES</span>      smile  frown  laugh  cry  sigh  nod  shake  dance  pace  stretch  wave  shrug  point
<span class="help-category">INTERACT</span>    lean on &lt;furniture&gt;  |  greet [player]  |  follow &lt;player&gt;  |  reflect
<span class="help-category">OBSERVE</span>     look sky  |  look ground  |  look distance  |  examine surroundings
<span class="help-category">INFO</span>        look  |  look &lt;me/item/player&gt;  |  examine &lt;thing&gt;  help`;
  if (player?.role === 'admin') {
    msg += `\n<span class="help-category">ADMIN</span>      teleport &lt;zone id&gt;  (tp)  |  spawn &lt;item id&gt; [zone|here]  |  spawnenemy &lt;enemy id&gt; [zone|here]`;
  }
  return { type:'help', message: msg };
}

async function cmdRaise(args, player) {
  await ensureTunables();
  const statName = args[0]?.toLowerCase();

  const { rows } = await query(
    'SELECT ip, stat_brawn, stat_reflexes, stat_endurance, stat_brains, stat_cool FROM players WHERE id=$1',
    [player.id]
  );
  const p = rows[0];

  if (!statName) {
    const ip = p?.ip || 0;
    let msg = `<span class="help-header">IMPROVEMENT POINTS — ${Math.floor(ip)} IP</span>\n\n`;
    for (const stat of RAISABLE_STATS) {
      const cur = p[`stat_${stat}`] || 0;
      const cost = statCost(cur);
      msg += `  ${stat.padEnd(12)} ${String(cur).padStart(2)}  →  ${cost} IP\n`;
    }
    msg += `\nUsage: raise <stat>`;
    return { type: 'help', message: msg };
  }

  const result = await raiseStat(player.id, statName);
  if (result.error) return { type: 'error', message: result.error };

  player[result.col] = result.to;

  const msg = `You invest ${result.cost} IP improving your ${result.stat} (${result.from} → ${result.to}).\nIP remaining: ${Math.floor(result.ip_remaining)}`;
  return { type: 'raise', message: msg, player_update: { [result.col]: result.to, ip: result.ip_remaining } };
}

async function cmdOpen(args, player) {
  // Furniture containers (e.g. the trash bin) are handled by the container
  // plugin's tag-gated `open` action, which runs before this built-in. What
  // reaches here is the window case.
  return cmdOpenWindow(args, player, 'open');
}

async function cmdOpenWindow(args, player, action) {
  // args: [handle, 'curtains'?] or [handle]
  if (!args.length) return { type:'error', message:`${action} what? Try: ${action} <window handle>` };
  const handle = args[0];
  const curtainsOnly = args[1] === 'curtains';
  const { rows } = await query('SELECT * FROM windows WHERE zone_interior=$1 AND (handle=$2 OR id=$2)', [player.current_zone, handle]);
  if (!rows.length) return { type:'error', message:`You don't see a window called "${handle}" here.` };
  const win = rows[0];
  if (action === 'open') {
    if (win.curtain_open && !curtainsOnly) return { type:'message', message:`The curtains on ${win.name} are already open.` };
    await query('UPDATE windows SET curtain_open=1 WHERE id=$1', [win.id]);
    return { type:'message', message:`You open the curtains on ${win.name}.` };
  } else {
    if (!win.curtain_open && !curtainsOnly) return { type:'message', message:`The curtains on ${win.name} are already closed.` };
    await query('UPDATE windows SET curtain_open=0 WHERE id=$1', [win.id]);
    return { type:'message', message:`You draw the curtains on ${win.name}.` };
  }
}

export const handlers = {
  examine:  (args, raw, player, broadcast) => cmdExamine(args.join(' '), player, broadcast),
  ex:       (args, raw, player, broadcast) => cmdExamine(args.join(' '), player, broadcast),
  x:        (args, raw, player, broadcast) => cmdExamine(args.join(' '), player, broadcast),
  stats:    (args, raw, player) => cmdStats(player),
  status:   (args, raw, player) => cmdStats(player),
  st:       (args, raw, player) => cmdStats(player),
  skills:   (args, raw, player) => cmdSkills(player),
  help:     (args, raw, player) => cmdHelp(player),
  '?':      (args, raw, player) => cmdHelp(player),
  teleport: (args, raw, player, broadcast) => cmdTeleport(args.join(' '), player, broadcast),
  tp:       (args, raw, player, broadcast) => cmdTeleport(args.join(' '), player, broadcast),
  open:     (args, raw, player) => cmdOpen(args, player),
  close:    (args, raw, player) => cmdOpenWindow(args, player, 'close'),
  raise:    (args, raw, player) => cmdRaise(args, player),
  ip:       (args, raw, player) => cmdRaise([], player),
  spawn:    (args, raw, player) => cmdSpawn(args, player),
  spawnenemy: (args, raw, player) => cmdSpawnEnemy(args, player),
};

// Lighting controls are owned by the lighting plugin (registered as specialized
// actions); exported here so that plugin can delegate to the engine logic.
export { cmdSwitch, cmdTurn };
