/**
 * Doors plugin — registers OPEN/CLOSE/LOCK/UNLOCK as specialized actions for
 * doors, replacing the old hard-coded door pre-intercept in commands/index.js.
 * The handlers (in engine/commands/doors.js) self-gate: they only act when the
 * target is a door ("open door north"), and otherwise return undefined so the
 * dispatcher falls through to containers, housing, and the built-ins.
 *
 * Lock types are registered here so adding a new lock type requires no engine
 * edits — drop a registerLockType() call in any plugin.
 */
import { handlers as doorHandlers } from '../../server/engine/commands/doors.js';
import { registerLockType } from '../../server/engine/locks.js';
import { query } from '../../server/models/db.js';
import { getApartment, getZone, getDoorById, setDoorCache } from '../../server/engine/world.js';
import { exitTargets } from '../../server/engine/exits.js';
import { playerControlsApt } from '../../server/engine/apartments.js';
import { schedule } from '../../server/engine/scheduler.js';
import { sendToZone } from '../../server/engine/messaging.js';

registerLockType('hololock', {
  tagType: 'lock:hololock',
  kitTag:  'lockkit:hololock',
  defaults: {
    difficulty: 5, canHack: true,
    messages: {
      lock:   'The hololock hums as it engages.',
      unlock: 'The hololock disengages with a soft click.',
      denied: 'The hololock does not recognize your credentials.',
    },
  },
  authFn: async (lockTag, door, player) => {
    // A door may be anchored on either side of the exit (see doorFarIds in
    // apartments.js) — check the apartment whichever side it's on.
    const farIds = door.target_zone ? [door.target_zone] : exitTargets(getZone(door.zone_id), door.exit_dir);
    for (const zid of [door.zone_id, ...farIds]) {
      const apt = getApartment(zid);
      if (apt && playerControlsApt(player, apt)) return true;
    }
    return false;
  },
});

registerLockType('keycardlock', {
  tagType: 'lock:keycardlock',
  kitTag:  'lockkit:keycardlock',
  defaults: {
    messages: {
      lock:   'The keycard reader beeps twice as the lock engages.',
      unlock: 'The keycard reader flashes green. The lock disengages.',
      denied: 'The keycard reader flashes red. Access denied.',
    },
  },
  authFn: async (lockTag, door, player) => {
    if (!lockTag.keyItemId) return false;
    const { rows } = await query(
      'SELECT 1 FROM player_inventory WHERE player_id=$1 AND item_id=$2 LIMIT 1',
      [player.id, lockTag.keyItemId]
    );
    return rows.length > 0;
  },
});

// Privacy lock — a simple bathroom-stall bolt. Anyone standing on the door's
// `privacySide` (the bathroom side, auto-detected at placement or set via the
// zone editor's lock-side switch) can lock AND unlock it; the other side is
// simply shut out while it's occupied. It's a manual bolt, so the door won't
// open for anyone while it's shut (passWhileLocked:false) — you slide it open to
// leave, which means you can't lock it behind you from the far side. Not
// hackable — bashing the door is the only forced entry, and the 10-minute
// auto-unlock sweep frees anyone who nodded off in a public stall.
registerLockType('privacylock', {
  tagType: 'lock:privacylock',
  kitTag:  'lockkit:privacylock',
  passWhileLocked: false,
  defaults: {
    messages: {
      lock:   'You slide the privacy bolt shut.',
      unlock: 'You slide the privacy bolt open.',
      denied: 'The privacy bolt only works from the other side.',
    },
  },
  authFn: async (lockTag, door, player) => player.current_zone === lockTag.privacySide,
});

// Every 10 minutes, spring every engaged privacy lock — a courtesy release so a
// player who fell asleep on the toilet doesn't seal a public bathroom forever.
schedule('10m', async () => {
  const { rows } = await query(
    `SELECT id, zone_id, target_zone FROM doors
      WHERE lock_state='locked' AND jsonb_exists(tags,'lock:privacylock')`
  );
  for (const row of rows) {
    await query('UPDATE doors SET lock_state=$1 WHERE id=$2', ['unlocked', row.id]);
    const cached = getDoorById(row.id);
    if (cached) setDoorCache(row.id, { ...cached, lock_state: 'unlocked' });
    for (const zid of [row.zone_id, row.target_zone].filter(Boolean)) {
      sendToZone(zid, { type: 'zone_event', message: 'The privacy bolt clicks open on its timer.', refresh: true });
    }
  }
});

export const specializedActions = [
  { verb: 'open',      handler: doorHandlers.open },
  { verb: 'close',     handler: doorHandlers.close },
  { verb: 'lock',      requiredTag: 'lockable', handler: doorHandlers.lock },
  { verb: 'unlock',    requiredTag: 'lockable', handler: doorHandlers.unlock },
  { verb: 'hack',      handler: doorHandlers.hack },
  { verb: 'install',   handler: doorHandlers.install },
  { verb: 'uninstall', handler: doorHandlers.uninstall },
];

export const commands = {
  hackresolve: doorHandlers.hackresolve,
};
