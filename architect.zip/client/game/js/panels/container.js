import { sendCmdSilent } from '../net.js';

let containerDraggedId = null;
let containerDragSource = null; // 'inv' or 'contents'
let containerDraggedQty = 1;
let dragHandled = false;
let activeContainerId = null;

export function openContainerPanel(data) {
  activeContainerId = data.containerId;
  renderContainerPanel(data);
  document.getElementById('container-panel').classList.add('active');
}

export function refreshContainerPanel(data) {
  if (!document.getElementById('container-panel').classList.contains('active')) return;
  activeContainerId = data.containerId;
  renderContainerPanel(data);
}

export function closeContainerPanel() {
  const cid = activeContainerId;
  document.getElementById('container-panel').classList.remove('active');
  activeContainerId = null;
  if (cid) sendCmdSilent(`closecontainer ${cid}`);
}

export function showContainerNotify(msg) {
  const el = document.getElementById('container-notify');
  if (!el) return;
  el.textContent = msg;
}

export function getActiveContainerId() { return activeContainerId; }

function formatWeight(g) {
  g = Number(g) || 0;
  if (g < 1000) return `${Math.round(g)}g`;
  return `${(Math.round(g / 100) / 10).toString()}kg`;
}

function promptQty(max, action) {
  if (max <= 1) return Promise.resolve(max);
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'qty-dialog-overlay';
    overlay.innerHTML = `
      <div class="qty-dialog">
        <div class="qty-dialog-label">How many? (1–${max})</div>
        <input class="qty-dialog-input" type="number" min="1" max="${max}" value="${max}">
        <div class="qty-dialog-btns">
          <button class="qty-dialog-ok">${action || 'OK'}</button>
          <button class="qty-dialog-cancel">Cancel</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const input = overlay.querySelector('.qty-dialog-input');
    input.focus();
    input.select();
    const finish = (qty) => { overlay.remove(); resolve(qty); };
    overlay.querySelector('.qty-dialog-ok').onclick = () => {
      const v = Math.min(max, Math.max(1, parseInt(input.value, 10) || 1));
      finish(v);
    };
    overlay.querySelector('.qty-dialog-cancel').onclick = () => finish(null);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') overlay.querySelector('.qty-dialog-ok').click();
      if (e.key === 'Escape') finish(null);
    });
    overlay.addEventListener('click', (e) => { if (e.target === overlay) finish(null); });
  });
}

function renderContainerPanel(data) {
  document.getElementById('container-title').textContent = data.containerName;
  document.getElementById('container-contents-label').textContent = data.containerName;
  document.getElementById('container-capacity').textContent =
    `Capacity: ${formatWeight(data.usedWeight)} / ${formatWeight(data.capacity)}`;
  const notify = document.getElementById('container-notify');
  if (notify) notify.textContent = data.notify || '';

  const invItems = (data.invItems || []).filter(i => i.id !== data.containerId);
  const containerItems = (data.containerItems || []).filter(i => i.id !== data.containerId);

  renderList('container-inv-list', invItems, 'inv', data.containerId);
  renderList('container-contents-list', containerItems, 'contents', data.containerId);

  document.getElementById('container-stow-all').style.display = invItems.length ? '' : 'none';
  document.getElementById('container-take-all').style.display = containerItems.length ? '' : 'none';
}

function renderList(listId, items, source, containerId) {
  const list = document.getElementById(listId);
  list.innerHTML = '';
  for (const item of items) {
    const card = document.createElement('div');
    card.className = 'ctr-item-card';
    card.setAttribute('draggable', 'true');
    card.setAttribute('data-id', item.id);
    card.setAttribute('data-source', source);
    const qty = item.quantity > 1 ? ` x${item.quantity}` : '';
    const wt = item.weight != null ? ` ${formatWeight(item.weight)}` : '';
    card.innerHTML = `<span class="ctr-name">${item.name}${qty}</span><span class="ctr-meta">${item.rarity || ''}${wt}</span>`;

    if (source === 'inv') {
      const btn = document.createElement('button');
      btn.className = 'ctr-action-btn';
      btn.textContent = 'stow';
      btn.title = 'Put into container';
      btn.onclick = async (e) => {
        e.stopPropagation();
        const qty = await promptQty(item.quantity, 'Stow');
        if (qty != null) {
          const qtyPart = item.quantity > 1 ? ` ${qty}` : '';
          sendCmdSilent(`stowid ${item.id} ${containerId}${qtyPart}`);
        }
      };
      card.appendChild(btn);
    } else {
      const btn = document.createElement('button');
      btn.className = 'ctr-action-btn';
      btn.textContent = 'take';
      btn.title = 'Take from container';
      btn.onclick = async (e) => {
        e.stopPropagation();
        const qty = await promptQty(item.quantity, 'Take');
        if (qty != null) {
          const qtyPart = item.quantity > 1 ? ` ${qty}` : '';
          sendCmdSilent(`pullid ${item.id}${qtyPart}`);
        }
      };
      card.appendChild(btn);
    }

    card.ondragstart = (e) => {
      containerDraggedId = item.id;
      containerDragSource = source;
      containerDraggedQty = item.quantity;
      dragHandled = false;
      card.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    };
    card.ondragend = () => card.classList.remove('dragging');
    list.appendChild(card);
  }
}

export function initContainerPanel() {
  document.getElementById('container-close').addEventListener('click', closeContainerPanel);
  document.getElementById('container-close-btn').addEventListener('click', closeContainerPanel);
  document.getElementById('container-panel').addEventListener('click', (e) => {
    if (e.target.id === 'container-panel') closeContainerPanel();
  });

  document.getElementById('container-stow-all').addEventListener('click', () => {
    if (!activeContainerId) return;
    const cards = document.getElementById('container-inv-list').querySelectorAll('.ctr-item-card');
    for (const card of cards) {
      sendCmdSilent(`stowid ${card.getAttribute('data-id')} ${activeContainerId}`);
    }
  });

  document.getElementById('container-take-all').addEventListener('click', () => {
    if (!activeContainerId) return;
    const cards = document.getElementById('container-contents-list').querySelectorAll('.ctr-item-card');
    for (const card of cards) {
      sendCmdSilent(`pullid ${card.getAttribute('data-id')}`);
    }
  });

  const invList = document.getElementById('container-inv-list');
  const contentsList = document.getElementById('container-contents-list');

  contentsList.addEventListener('dragover', (e) => e.preventDefault());
  contentsList.addEventListener('dragenter', () => contentsList.classList.add('ctr-drag-over'));
  contentsList.addEventListener('dragleave', () => contentsList.classList.remove('ctr-drag-over'));
  contentsList.addEventListener('drop', async (e) => {
    e.preventDefault();
    contentsList.classList.remove('ctr-drag-over');
    dragHandled = true;
    if (containerDraggedId && containerDragSource === 'inv' && activeContainerId) {
      const dragId = containerDraggedId;
      const dragQty = containerDraggedQty;
      containerDraggedId = null;
      const qty = await promptQty(dragQty, 'Stow');
      if (qty != null) {
        const qtyPart = dragQty > 1 ? ` ${qty}` : '';
        sendCmdSilent(`stowid ${dragId} ${activeContainerId}${qtyPart}`);
      }
    } else {
      containerDraggedId = null;
    }
  });

  invList.addEventListener('dragover', (e) => e.preventDefault());
  invList.addEventListener('dragenter', () => invList.classList.add('ctr-drag-over'));
  invList.addEventListener('dragleave', () => invList.classList.remove('ctr-drag-over'));
  invList.addEventListener('drop', async (e) => {
    e.preventDefault();
    invList.classList.remove('ctr-drag-over');
    dragHandled = true;
    if (containerDraggedId && containerDragSource === 'contents') {
      const dragId = containerDraggedId;
      const dragQty = containerDraggedQty;
      containerDraggedId = null;
      const qty = await promptQty(dragQty, 'Take');
      if (qty != null) {
        const qtyPart = dragQty > 1 ? ` ${qty}` : '';
        sendCmdSilent(`pullid ${dragId}${qtyPart}`);
      }
    } else {
      containerDraggedId = null;
    }
  });

  document.addEventListener('dragend', () => {
    dragHandled = false;
    containerDraggedId = null;
    containerDragSource = null;
    containerDraggedQty = 1;
  });
}
